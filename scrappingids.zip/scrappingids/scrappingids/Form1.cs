﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace scrappingids
{
    public partial class Form1 : Form
    {
        HtmlAgilityPack.HtmlWeb web = new HtmlAgilityPack.HtmlWeb();//create the object
        HtmlAgilityPack.HtmlDocument doc;//create the object
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            doc = web.Load("http://example.python-scraping.com/places/default/view/Anguilla-8");//load th web
            getbyids("places_area__label");//get data by id
            getbyclass("w2p_fw");
        }
        void getbyids(string id)
        {
            string data = doc.GetElementbyId(id).InnerText;
            MessageBox.Show(data);
        }
        void getbyclass(string classname)
        {
            var classes = doc.DocumentNode.Descendants().Where(n => n.HasClass(classname));
            foreach(var data in classes)
            {
                MessageBox.Show(data.InnerText);
            }
        }
    }
}
